#! /bin/bash

file_remove="$directory_name"

rm -r file_remove/*.*


